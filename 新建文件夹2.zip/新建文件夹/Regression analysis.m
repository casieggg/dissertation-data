clc,clear
load zhufang.txt %把原始的自变量因变量数据存在纯文本文件中
[m,n]=size(zhufang);
x0=zhufang(:,[1:n-1]);y0=zhufang(:,n);
hg1=[ones(m,1),x0]\y0;%计算普通最小二乘法回归分析系数
hg1=hg1'%变成行向量显示回归系数，其中第一个分量是常数项，其他按x1,…，xn排序
fprintf('y=%f',hg1(1));
for i=2:n
     if hg1(i)>0
        fprintf('+%f*x% d',hg1(i),i-1);
     else
        fprintf('%f*x%d',hg1(i),i-1)
     end
end
fprintf('\n')
r=corrcoef(x0)%计算相关系数矩阵
xd =zscore(x0);%对设计矩阵进行标准化处理
yd=zscore(y0);%对y0进行标准化处理
[vec1,lamda,rate]=pcacov(r)%vec1为r的特征向量，lamda为r的特征值，rate为哥哥主成分的贡献率
f=repmat(sign(sum(vec1)),size(vec1,1),1);%构造与vec1同维数的元素为+1，-1的矩阵
vec2=vec1.*f%修改特征向量的正负号，使得每个特征向量的分量和为正
contr=cumsum(rate)%计算累计贡献率，第i个分量表示前i个主成分的贡献率
df=xd*vec2;%计算所有主成分的得分
num=input('请选项主成分的个数：')
hg21=df(:,[1:num])\yd
hg22=vec2(:,1:num)*hg21
hg23=[mean(y0)-std(y0)*mean(x0)./std(x0)*hg22,std(y0)*hg22'./std(x0)]
fprintf('y=%f',hg23(1));
for i =2:n
     if hg23(i)>0
        fprintf('+%f*x% d',hg23(i),i-1);
     else
        fprintf('%f*x%d',hg23(i),i-1);
     end
end
fprintf('\n')
rmse1=sqrt(sum((hg1(1)-x0*hg1(2:end)'-y0).^2)/(m-n))
rmse2=sqrt(sum((hg23(1)-x0*hg23(2:end)'-y0).^2)/(m-num))